<template>
  <router-view id="app" class="view"></router-view>
</template>
<style lang="less" scoped>
</style>
