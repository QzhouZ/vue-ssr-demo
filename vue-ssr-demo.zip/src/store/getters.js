export default {
  deptData: state => {
    return state.pages.list.deptData
  }
}
