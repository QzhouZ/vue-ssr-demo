export default {
  pages: {
    list: {
      deptData: []
    }
  }
}
